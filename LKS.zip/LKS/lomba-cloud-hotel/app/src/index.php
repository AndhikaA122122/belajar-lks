<?php
session_start();
require_once 'config.php';

$hotel_name = "Grand Andhika Hotel";
$hotel_address = "Jl. Gatot Subroto No. 88, Medan, Sumatera Utara";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $hotel_name ?> - Buku Tamu Digital</title>
    <!-- Bootstrap 5 + Icons + Google Font -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e9ecf2 100%);
            min-height: 100vh;
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: -0.5px;
        }
        .hero-card {
            border: none;
            border-radius: 24px;
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.08), 0 6px 12px rgba(0,0,0,0.05);
            transition: transform 0.2s ease;
        }
        .hero-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 30px 50px rgba(0,0,0,0.12);
        }
        .section-title {
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 1.5rem;
            position: relative;
            display: inline-block;
        }
        .section-title:after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #3b82f6, #8b5cf6);
            border-radius: 4px;
        }
        .btn-gradient {
            background: linear-gradient(145deg, #2563eb, #4f46e5);
            border: none;
            color: white;
            font-weight: 600;
            padding: 10px 24px;
            border-radius: 40px;
            box-shadow: 0 8px 16px rgba(37,99,235,0.2);
            transition: all 0.2s;
        }
        .btn-gradient:hover {
            background: linear-gradient(145deg, #1d4ed8, #4338ca);
            box-shadow: 0 12px 20px rgba(37,99,235,0.3);
            color: white;
        }
        .table-custom {
            background: white;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
        }
        .table-custom thead {
            background: #1e293b;
            color: white;
        }
        .table-custom th {
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
            padding: 16px;
        }
        .table-custom td {
            padding: 14px 16px;
            vertical-align: middle;
        }
        .badge-hotel {
            background: linear-gradient(145deg, #f59e0b, #f97316);
            color: white;
            font-weight: 500;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .footer-note {
            font-size: 0.85rem;
            color: #64748b;
        }
        .input-group-text {
            background: white;
            border-right: none;
        }
        .form-control, .form-select {
            border-left: none;
            padding: 12px 16px;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            background: white;
        }
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59,130,246,0.1);
        }
    </style>
</head>
<body>

<!-- Navbar Elegan -->
<nav class="navbar navbar-expand-lg sticky-top" style="background: rgba(255,255,255,0.8); backdrop-filter: blur(12px); box-shadow: 0 4px 12px rgba(0,0,0,0.02);">
    <div class="container py-2">
        <a class="navbar-brand" href="#">
            <i class="bi bi-building fs-3 me-2" style="color: #2563eb;"></i>
            <span style="color: #0f172a;">Grand Andhika</span>
            <span style="color: #2563eb; font-weight: 300;">Hotel</span>
        </a>
        <div class="navbar-nav ms-auto">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a class="nav-link me-3" href="admin.php"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
                <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i> Keluar</a>
            <?php else: ?>
                <a class="nav-link btn btn-outline-primary rounded-pill px-4" href="login.php">
                    <i class="bi bi-shield-lock me-1"></i> Login Admin
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container py-5">
    <!-- Header dengan Alamat -->
    <div class="row mb-5">
        <div class="col-lg-8 mx-auto text-center">
            <span class="badge-hotel mb-3"><i class="bi bi-star-fill me-1"></i> Bintang 5 · Hospitality Excellence</span>
            <h1 class="display-5 fw-bold" style="color: #0f172a;"><?= $hotel_name ?></h1>
            <p class="lead text-secondary"><i class="bi bi-geo-alt-fill me-1" style="color: #dc2626;"></i> <?= $hotel_address ?></p>
        </div>
    </div>

    <div class="row g-5">
        <!-- Kolom Kiri: Form Tambah Tamu -->
        <div class="col-lg-5">
            <div class="hero-card p-4 p-xl-5">
                <h4 class="section-title"><i class="bi bi-pencil-square me-2"></i>Tulis Kesan Anda</h4>
                <p class="text-muted mb-4">Isi data diri dan pengalaman menginap Anda.</p>
                
                <form method="POST" action="add_guest.php">
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Nama Lengkap</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white border-end-0 rounded-start-4"><i class="bi bi-person"></i></span>
                            <input type="text" name="nama_tamu" class="form-control border-start-0 rounded-end-4" placeholder="Contoh: Budi Santoso" required>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Nomor Telepon</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white border-end-0 rounded-start-4"><i class="bi bi-telephone"></i></span>
                            <input type="text" name="no_telp" class="form-control border-start-0 rounded-end-4" placeholder="0812-3456-7890" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-semibold">Nomor Kamar</label>
                            <input type="text" name="no_kamar" class="form-control rounded-4" placeholder="101" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-semibold">Lama Inap (malam)</label>
                            <input type="number" name="lama_inap" class="form-control rounded-4" min="1" value="1" required>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Komentar / Kesan</label>
                        <textarea name="komentar" class="form-control rounded-4" rows="4" placeholder="Ceritakan pengalaman menginap Anda..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-gradient w-100 py-3">
                        <i class="bi bi-send-fill me-2"></i>Kirim Kesan
                    </button>
                </form>
            </div>
        </div>

        <!-- Kolom Kanan: Daftar Tamu Terkini -->
        <div class="col-lg-7">
            <div class="hero-card p-4 p-xl-5">
                <div class="d-flex align-items-center mb-4">
                    <h4 class="section-title mb-0"><i class="bi bi-people-fill me-2"></i>Tamu Terkini</h4>
                    <span class="ms-auto badge bg-light text-dark rounded-pill px-3 py-2">
                        <i class="bi bi-database me-1"></i> Read Replica
                    </span>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-custom align-middle">
                        <thead>
                            <tr>
                                <th>Nama Tamu</th>
                                <th>Kamar</th>
                                <th>Inap</th>
                                <th>Check-in</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            try {
                                $conn_read = new mysqli(DB_HOST_READ, DB_USER, DB_PASS, DB_NAME);
                                if ($conn_read->connect_error) {
                                    echo '<tr><td colspan="4" class="text-center text-danger py-4"><i class="bi bi-exclamation-triangle me-2"></i>Gagal terhubung ke database</td></tr>';
                                } else {
                                    $result = $conn_read->query("SELECT nama_tamu, no_kamar, lama_inap, created_at FROM guests ORDER BY created_at DESC LIMIT 8");
                                    if ($result && $result->num_rows > 0) {
                                        while($row = $result->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td><i class="bi bi-person-circle me-2 text-primary"></i>' . htmlspecialchars($row['nama_tamu']) . '</td>';
                                            echo '<td><span class="badge bg-light text-dark rounded-pill px-3 py-2">' . htmlspecialchars($row['no_kamar']) . '</span></td>';
                                            echo '<td>' . htmlspecialchars($row['lama_inap']) . ' malam</td>';
                                            echo '<td><i class="bi bi-calendar3 me-1 text-secondary"></i>' . date('d M Y', strtotime($row['created_at'])) . '</td>';
                                            echo '</tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="4" class="text-center py-4 text-muted"><i class="bi bi-journal-x me-2"></i>Belum ada tamu yang mengisi buku tamu</td></tr>';
                                    }
                                    $conn_read->close();
                                }
                            } catch (Exception $e) {
                                echo '<tr><td colspan="4" class="text-center text-danger py-4">Error: ' . htmlspecialchars($e->getMessage()) . '</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="footer-note mt-3 d-flex align-items-center">
                    <i class="bi bi-info-circle-fill me-2" style="color: #3b82f6;"></i>
                    Data ditampilkan dari database replica (read-only) untuk performa optimal.
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>