<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: admin.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'config.php';
    
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $conn = new mysqli(DB_HOST_WRITE, DB_USER, DB_PASS, DB_NAME);
    
    if (!$conn->connect_error) {
        $stmt = $conn->prepare("SELECT id, username, password FROM admin_users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                header('Location: admin.php');
                exit;
            } else {
                $error = 'Password tidak cocok!';
            }
        } else {
            $error = 'Username tidak ditemukan!';
        }
        $conn->close();
    } else {
        $error = 'Gagal terhubung ke database.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin · Grand Andhika Hotel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at 10% 30%, #e0e7ff, #f3f4f6);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 20px;
        }
        .login-card {
            border: none;
            border-radius: 32px;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(12px);
            box-shadow: 0 30px 60px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 420px;
            width: 100%;
            margin: auto;
        }
        .login-header {
            background: linear-gradient(145deg, #1e293b, #0f172a);
            padding: 2rem 2rem 1.5rem;
            text-align: center;
        }
        .login-body {
            padding: 2.5rem 2rem;
        }
        .form-control {
            border-radius: 16px;
            padding: 14px 18px;
            border: 1px solid #e2e8f0;
            background: white;
        }
        .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37,99,235,0.15);
        }
        .btn-login {
            background: linear-gradient(145deg, #2563eb, #4f46e5);
            border: none;
            border-radius: 40px;
            padding: 14px;
            font-weight: 700;
            color: white;
            width: 100%;
            transition: all 0.2s;
            box-shadow: 0 8px 16px rgba(37,99,235,0.2);
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 24px rgba(37,99,235,0.3);
        }
        .error-toast {
            background: #fee2e2;
            color: #b91c1c;
            border-radius: 40px;
            padding: 12px 20px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header">
        <i class="bi bi-building fs-1 text-white mb-2"></i>
        <h2 class="text-white fw-bold">Grand Andhika</h2>
        <p class="text-white-50 mb-0">Panel Administrasi</p>
    </div>
    <div class="login-body">
        <?php if ($error): ?>
            <div class="error-toast d-flex align-items-center mb-4">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-4">
                <label class="form-label fw-semibold">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" class="form-control border-start-0" placeholder="admin" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control border-start-0" placeholder="········" required>
                </div>
            </div>
            <button type="submit" class="btn btn-login">
                <i class="bi bi-box-arrow-in-right me-2"></i>Masuk Dashboard
            </button>
        </form>
        <p class="text-muted text-center small mt-4 mb-0">
            <i class="bi bi-shield-shaded"></i> Akses terbatas hanya untuk staf hotel
        </p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>